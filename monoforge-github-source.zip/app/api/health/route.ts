import { NextResponse } from "next/server";
import { getClientIpFromHeaders } from "@/lib/security/client-ip";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";

export function GET(request: Request) {
  try {
    enforceRateLimit("health", getClientIpFromHeaders(request.headers));
  } catch (error) {
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  return NextResponse.json({ ok: true, service: "monoforge" });
}
