import { createReadStream } from "node:fs";
import { Readable } from "node:stream";
import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { FileKind, FileVariantKind } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { normalizeRepoPath } from "@/lib/repository/paths";
import { ensureRepoReadable } from "@/server/repositories/files";
import { getStoragePath } from "@/server/storage/paths";

type ThumbnailRouteProps = {
  params: Promise<{ owner: string; repo: string; path: string[] }>;
};

export async function GET(request: Request, { params }: ThumbnailRouteProps) {
  const { owner, repo, path } = await params;
  const session = await getApiSession(request);
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const kind = new URL(request.url).searchParams.get("kind") === "preview" ? FileVariantKind.IMAGE_PREVIEW : FileVariantKind.IMAGE_THUMBNAIL;
  const repoPath = normalizeRepoPath(path.join("/"));
  const file = await getPrisma().repositoryFile.findUnique({
    where: {
      repositoryId_path: {
        repositoryId: repository.id,
        path: repoPath,
      },
    },
    include: {
      blob: {
        include: {
          variants: {
            where: { kind },
            take: 1,
          },
        },
      },
    },
  });

  const variant = file?.blob?.variants[0];

  if (!file || file.kind !== FileKind.FILE || !variant) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return new Response(Readable.toWeb(createReadStream(getStoragePath(variant.storageKey))) as ReadableStream, {
    headers: {
      "Content-Type": variant.mimeType,
      "Cache-Control": "private, max-age=3600",
      "Content-Length": variant.byteSize.toString(),
    },
  });
}
