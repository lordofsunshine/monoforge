import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { getRepositoryIssueContext } from "@/server/issues/access";
import { getRepositoryLabels } from "@/server/issues/labels";

type LabelsRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: LabelsRouteProps) {
  const { owner, repo } = await params;
  const session = await getApiSession(request);
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const labels = await getRepositoryLabels(repository.id);
  return NextResponse.json({ labels });
}
