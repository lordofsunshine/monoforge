import { NextResponse } from "next/server";
import { FileKind } from "@/generated/prisma/client";
import { getApiSession } from "@/lib/auth/api";
import { getPrisma } from "@/lib/prisma";
import { normalizeRepoPath } from "@/lib/repository/paths";
import { ensureRepoReadable, readRepositoryFileText, textPreviewLimit } from "@/server/repositories/files";

type PreviewRouteProps = {
  params: Promise<{ owner: string; repo: string; path: string[] }>;
};

export async function GET(request: Request, { params }: PreviewRouteProps) {
  const { owner, repo, path } = await params;
  const session = await getApiSession(request);
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const repoPath = normalizeRepoPath(path.join("/"));
  const file = await getPrisma().repositoryFile.findUnique({
    where: {
      repositoryId_path: {
        repositoryId: repository.id,
        path: repoPath,
      },
    },
    select: { id: true, kind: true, size: true, isBinary: true },
  });

  if (!file || file.kind !== FileKind.FILE) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (file.isBinary || Number(file.size) > textPreviewLimit) {
    return NextResponse.json({ error: "Preview blocked" }, { status: 413 });
  }

  const content = await readRepositoryFileText(file.id);
  return NextResponse.json({ content });
}
