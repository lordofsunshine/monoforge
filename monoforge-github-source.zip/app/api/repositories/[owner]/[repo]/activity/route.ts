import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { getPrisma } from "@/lib/prisma";
import { ensureRepoReadable } from "@/server/repositories/files";

type ActivityRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: ActivityRouteProps) {
  const session = await getApiSession(request);
  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const activity = await getPrisma().repoActivity.findMany({
    where: { repositoryId: repository.id },
    orderBy: { createdAt: "desc" },
    take: 30,
    include: {
      actor: {
        select: { username: true },
      },
    },
  });

  return NextResponse.json({
    activity: activity.map((item) => ({
      ...item,
      createdAt: item.createdAt.toISOString(),
    })),
  });
}
