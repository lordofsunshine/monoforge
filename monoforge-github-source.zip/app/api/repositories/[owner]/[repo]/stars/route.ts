import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { ensureRepoReadable } from "@/server/repositories/files";
import { setRepositoryStar } from "@/server/repositories/stars";

type StarsRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function POST(request: Request, { params }: StarsRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    enforceRateLimit("star", session.user.id);
  } catch (error) {
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const result = await setRepositoryStar({
    repositoryId: repository.id,
    userId: session.user.id,
    starred: true,
  });

  return NextResponse.json({ ok: true, ...result }, { status: 201 });
}

export async function PUT(request: Request, context: StarsRouteProps) {
  return POST(request, context);
}

export async function DELETE(request: Request, { params }: StarsRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    enforceRateLimit("star", session.user.id);
  } catch (error) {
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const result = await setRepositoryStar({
    repositoryId: repository.id,
    userId: session.user.id,
    starred: false,
  });

  return NextResponse.json({ ok: true, ...result });
}
