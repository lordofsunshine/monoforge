﻿import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { getPrisma } from "@/lib/prisma";
import { webhookSchema } from "@/lib/validation/webhook";
import { ensureRepoReadable } from "@/server/repositories/files";
import { createWebhook } from "@/server/storage/webhooks";

type WebhooksRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: WebhooksRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const webhooks = await getPrisma().webhook.findMany({
    where: { repositoryId: repository.id },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      url: true,
      events: true,
      status: true,
      lastStatus: true,
      lastError: true,
      lastSentAt: true,
      createdAt: true,
    },
  });

  return NextResponse.json({
    webhooks: webhooks.map((webhook) => ({
      ...webhook,
      lastSentAt: webhook.lastSentAt?.toISOString() ?? null,
      createdAt: webhook.createdAt.toISOString(),
    })),
  });
}

export async function POST(request: Request, { params }: WebhooksRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const parsed = webhookSchema.safeParse(await request.json().catch(() => null));

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid webhook" }, { status: 400 });
  }

  const webhook = await createWebhook({ repositoryId: repository.id, ...parsed.data });

  return NextResponse.json({
    webhook: {
      id: webhook.id,
      url: webhook.url,
      events: webhook.events,
      status: webhook.status,
      lastStatus: webhook.lastStatus,
      lastError: webhook.lastError,
      lastSentAt: webhook.lastSentAt?.toISOString() ?? null,
      createdAt: webhook.createdAt.toISOString(),
    },
  }, { status: 201 });
}
