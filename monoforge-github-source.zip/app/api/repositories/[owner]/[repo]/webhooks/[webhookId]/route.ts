﻿import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { ensureRepoReadable } from "@/server/repositories/files";
import { deleteWebhook } from "@/server/storage/webhooks";

type WebhookRouteProps = {
  params: Promise<{ owner: string; repo: string; webhookId: string }>;
};

export async function DELETE(request: Request, { params }: WebhookRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo, webhookId } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await deleteWebhook(webhookId, repository.id);
  return NextResponse.json({ ok: true });
}
