import { Readable, PassThrough } from "node:stream";
import { ZipFile } from "yazl";
import { FileKind } from "@/generated/prisma/client";
import { getApiSession } from "@/lib/auth/api";
import { getPrisma } from "@/lib/prisma";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { acquireArchiveDownloadSlot, maxArchiveFileCount, shouldAllowArchiveDownload } from "@/server/repositories/archive-policy";
import { ensureRepoReadable } from "@/server/repositories/files";
import { streamBlobToOutput } from "@/server/storage/service";

type ArchiveRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

function safeArchiveName(value: string) {
  return value.replace(/[^a-z0-9._-]+/gi, "-").replace(/^-+|-+$/g, "") || "repository";
}

function safeZipPath(repo: string, filePath: string) {
  const root = safeArchiveName(repo);
  const normalized = filePath.replaceAll("\\", "/").split("/").filter(Boolean).join("/");
  return `${root}/${normalized}`;
}

export async function GET(request: Request, { params }: ArchiveRouteProps) {
  const { owner, repo } = await params;
  const session = await getApiSession(request);
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";

  try {
    enforceRateLimit("archive", session?.user?.id || ip);
  } catch (error) {
    if (error instanceof RateLimitError) {
      return Response.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return Response.json({ error: "Not found" }, { status: 404 });
  }

  const prisma = getPrisma();
  const where = {
    repositoryId: repository.id,
    kind: FileKind.FILE,
    blobId: { not: null },
  };
  const stats = await prisma.repositoryFile.aggregate({
    where,
    _count: { _all: true },
    _sum: { size: true },
  });

  if (!shouldAllowArchiveDownload({ fileCount: stats._count._all, totalSize: stats._sum.size || 0n })) {
    return Response.json({ error: "Repository archive is too large" }, { status: 413 });
  }

  let releaseArchiveSlot: (() => void) | null = null;

  try {
    releaseArchiveSlot = acquireArchiveDownloadSlot(repository.id);
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Archive generation is busy" }, { status: 429 });
  }

  const files = await prisma.repositoryFile.findMany({
    where,
    include: { blob: true },
    orderBy: [{ path: "asc" }],
    take: maxArchiveFileCount,
  });

  const zip = new ZipFile();
  const archiveName = `${safeArchiveName(repository.owner.username)}-${safeArchiveName(repository.slug)}.zip`;
  zip.outputStream.once("close", () => releaseArchiveSlot?.());
  zip.outputStream.once("error", () => releaseArchiveSlot?.());
  request.signal.addEventListener("abort", () => releaseArchiveSlot?.(), { once: true });

  for (const file of files) {
    if (!file.blob) {
      continue;
    }

    zip.addReadStreamLazy(
      safeZipPath(repository.slug, file.path),
      {
        compress: false,
        mtime: file.updatedAt,
        mode: 0o100644,
        size: Number(file.size),
      },
      (callback) => {
        const stream = new PassThrough();
        streamBlobToOutput(file.blob!, stream).catch((error) => stream.destroy(error));
        callback(null, stream);
      },
    );
  }

  zip.end();

  return new Response(Readable.toWeb(zip.outputStream as Readable) as ReadableStream, {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="${archiveName}"`,
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
