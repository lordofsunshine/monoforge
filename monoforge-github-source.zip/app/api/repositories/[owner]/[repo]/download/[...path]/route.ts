import { NextResponse } from "next/server";
import { PassThrough, Readable } from "node:stream";
import { auth } from "@/auth";
import { FileKind } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { normalizeRepoPath } from "@/lib/repository/paths";
import { safeDownloadFileName } from "@/lib/security/file-policy";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { ensureRepoReadable } from "@/server/repositories/files";
import { streamBlobToOutput } from "@/server/storage/service";

type DownloadRouteProps = {
  params: Promise<{ owner: string; repo: string; path: string[] }>;
};

export async function GET(request: Request, { params }: DownloadRouteProps) {
  const { owner, repo, path } = await params;
  const session = await auth();
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";

  try {
    enforceRateLimit("download", session?.user?.id || ip);
  } catch (error) {
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const repoPath = normalizeRepoPath(path.join("/"));
  const file = await getPrisma().repositoryFile.findUnique({
    where: {
      repositoryId_path: {
        repositoryId: repository.id,
        path: repoPath,
      },
    },
    include: { blob: true },
  });

  if (!file?.blob || file.kind !== FileKind.FILE) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const passThrough = new PassThrough();
  const fileName = safeDownloadFileName(file.name);
  streamBlobToOutput(file.blob, passThrough).catch((error) => {
    passThrough.destroy(error);
  });

  return new Response(Readable.toWeb(passThrough) as ReadableStream, {
    headers: {
      "Content-Type": file.mimeType || "application/octet-stream",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Content-Length": file.size.toString(),
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "private, no-store",
    },
  });
}
