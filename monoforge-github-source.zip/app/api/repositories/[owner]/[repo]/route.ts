import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { getPrisma } from "@/lib/prisma";
import { writeAuditLog } from "@/lib/security/audit-log";
import { usernameSchema } from "@/lib/validation/auth";
import { slugifyRepositoryName, updateRepositorySchema } from "@/lib/validation/repository";
import { ActivityType, RepositoryVisibility } from "@/generated/prisma/client";

type RepositoryRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(_request: Request, { params }: RepositoryRouteProps) {
  const { owner, repo } = await params;
  const ownerParsed = usernameSchema.safeParse(owner);
  const repoParsed = usernameSchema.safeParse(repo);

  if (!ownerParsed.success || !repoParsed.success) {
    return NextResponse.json({ error: "Invalid repository path" }, { status: 400 });
  }

  const session = await auth();
  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repoParsed.data,
      owner: { username: ownerParsed.data },
    },
    include: {
      owner: {
        select: {
          id: true,
          username: true,
          image: true,
        },
      },
    },
  });

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (repository.visibility === RepositoryVisibility.PRIVATE && repository.ownerId !== session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  return NextResponse.json({ repository });
}

export async function PATCH(request: Request, { params }: RepositoryRouteProps) {
  const session = await auth();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const body = await request.json().catch(() => null);
  const parsed = updateRepositorySchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      owner: { username: owner.toLowerCase() },
    },
    select: { id: true, ownerId: true, name: true, slug: true, visibility: true },
  });

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const nextSlug = slugifyRepositoryName(parsed.data.name);
  const updated = await prisma.repository.update({
    where: { id: repository.id },
    data: {
      name: parsed.data.name,
      slug: nextSlug,
      description: parsed.data.description || null,
      visibility: parsed.data.visibility as RepositoryVisibility,
    },
  });

  if (repository.visibility !== parsed.data.visibility) {
    await prisma.repoActivity.create({
      data: {
        repositoryId: repository.id,
        actorId: session.user.id,
        type: ActivityType.REPOSITORY_VISIBILITY_CHANGED,
        title: `Visibility changed to ${parsed.data.visibility.toLowerCase()}`,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "CHANGE_REPOSITORY_VISIBILITY",
      repositoryId: repository.id,
      target: updated.slug,
      metadata: { from: repository.visibility, to: parsed.data.visibility },
    });
  }

  if (repository.name !== parsed.data.name || repository.slug !== nextSlug) {
    await prisma.repoActivity.create({
      data: {
        repositoryId: repository.id,
        actorId: session.user.id,
        type: ActivityType.REPOSITORY_RENAMED,
        title: `Repository renamed to ${nextSlug}`,
      },
    });
    await writeAuditLog({
      actorId: session.user.id,
      action: "RENAME_REPOSITORY",
      repositoryId: repository.id,
      target: nextSlug,
      metadata: { from: repository.slug, to: nextSlug },
    });
  }

  return NextResponse.json({ repository: updated });
}

export async function DELETE(_request: Request, { params }: RepositoryRouteProps) {
  const session = await auth();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      owner: { username: owner.toLowerCase() },
    },
    select: { id: true, ownerId: true, slug: true },
  });

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await writeAuditLog({
    actorId: session.user.id,
    action: "DELETE_REPOSITORY",
    repositoryId: repository.id,
    target: repository.slug,
  });

  await prisma.repository.delete({
    where: { id: repository.id },
  });

  return NextResponse.json({ ok: true });
}
