import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { getPrisma } from "@/lib/prisma";
import { usernameSchema } from "@/lib/validation/auth";
import { repositorySlugSchema, updateRepositorySchema } from "@/lib/validation/repository";
import { RepositoryVisibility } from "@/generated/prisma/client";
import { deleteRepositoryForUser, updateRepositoryForUser } from "@/server/repositories/service";

type RepositoryRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: RepositoryRouteProps) {
  const { owner, repo } = await params;
  const ownerParsed = usernameSchema.safeParse(owner);
  const repoParsed = repositorySlugSchema.safeParse(repo);

  if (!ownerParsed.success || !repoParsed.success) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const session = await getApiSession(request);
  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repoParsed.data,
      owner: { username: ownerParsed.data },
    },
    include: {
      owner: {
        select: {
          id: true,
          username: true,
          image: true,
        },
      },
    },
  });

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (repository.visibility === RepositoryVisibility.PRIVATE && repository.ownerId !== session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  return NextResponse.json({ repository });
}

export async function PATCH(request: Request, { params }: RepositoryRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const body = await request.json().catch(() => null);
  const parsed = updateRepositorySchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      owner: { username: owner.toLowerCase() },
    },
    select: { id: true, ownerId: true, name: true, slug: true, visibility: true },
  });

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const updated = await updateRepositoryForUser(repository.id, session.user.id, parsed.data).catch((error) => error as Error);

  if (updated instanceof Error) {
    return NextResponse.json({ error: updated.message }, { status: 400 });
  }

  return NextResponse.json({ repository: updated });
}

export async function DELETE(request: Request, { params }: RepositoryRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      owner: { username: owner.toLowerCase() },
    },
    select: { id: true, ownerId: true, slug: true },
  });

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const deleted = await deleteRepositoryForUser({ repositoryId: repository.id, actorId: session.user.id }).catch((error) => error as Error);

  if (deleted instanceof Error) {
    return NextResponse.json({ error: deleted.message }, { status: 400 });
  }

  return NextResponse.json({ ok: true });
}
