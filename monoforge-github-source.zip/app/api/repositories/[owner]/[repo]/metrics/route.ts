import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { ensureRepoReadable } from "@/server/repositories/files";
import { getRepoMetrics } from "@/server/repositories/metrics";

type MetricsRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: MetricsRouteProps) {
  const session = await getApiSession(request);
  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const metrics = await getRepoMetrics(repository.id);

  return NextResponse.json({
    metrics: {
      ...metrics,
      repoSize: metrics.repoSize.toString(),
      logicalOriginalSize: metrics.logicalOriginalSize.toString(),
      compressedSize: metrics.compressedSize.toString(),
      compressionSavedBytes: metrics.compressionSavedBytes.toString(),
      lastUpdate: metrics.lastUpdate.toISOString(),
    },
  });
}
