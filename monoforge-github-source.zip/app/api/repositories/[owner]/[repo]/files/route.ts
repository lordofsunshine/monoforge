import { NextResponse } from "next/server";
import { Readable } from "node:stream";
import Busboy from "busboy";
import { FileKind } from "@/generated/prisma/client";
import { getApiSession } from "@/lib/auth/api";
import { getEnv } from "@/lib/env";
import { getPrisma } from "@/lib/prisma";
import { normalizeRepoPath } from "@/lib/repository/paths";
import { getClientIpFromHeaders } from "@/lib/security/client-ip";
import { toSafeError, logServerError } from "@/lib/security/secure-error";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { ensureRepoReadable, uploadRepositoryFilesBatch } from "@/server/repositories/files";
import { acquireUploadSlot } from "@/server/storage/limits";
import { writeUploadToTemp } from "@/server/storage/service";

type FilesRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: FilesRouteProps) {
  const { owner, repo } = await params;
  const session = await getApiSession(request);

  try {
    enforceRateLimit("browse", session?.user?.id || getClientIpFromHeaders(request.headers));
  } catch (error) {
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const url = new URL(request.url);
  const rawParentPath = url.searchParams.get("parentPath")?.trim() || "";
  let parentPath = "";

  try {
    parentPath = rawParentPath && rawParentPath !== "/" ? normalizeRepoPath(rawParentPath.replace(/^\/+|\/+$/g, "")) : "";
  } catch {
    return NextResponse.json({ error: "Invalid parent path" }, { status: 400 });
  }
  const prisma = getPrisma();
  const files = await prisma.repositoryFile.findMany({
    where: {
      repositoryId: repository.id,
      parentPath,
    },
    orderBy: [{ kind: "asc" }, { name: "asc" }],
    take: 200,
  });

  return NextResponse.json({ files });
}

export async function POST(request: Request, { params }: FilesRouteProps) {
  const releaseSlot = await acquireUploadSlot().catch((error) => error as Error);

  if (releaseSlot instanceof Error) {
    return NextResponse.json({ error: releaseSlot.message }, { status: 429 });
  }

  const session = await getApiSession(request);

  if (!session?.user?.id) {
    releaseSlot();
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    enforceRateLimit("upload", session.user.id);
  } catch (error) {
    releaseSlot();
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || repository.ownerId !== session.user.id) {
    releaseSlot();
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let cleanupUpload: (() => Promise<void>) | null = null;

  try {
    const upload = await parseMultipartUpload(request, session.user.id);
    cleanupUpload = upload.cleanup;
    const message = (upload.fields.message || "").trim();

    if (message.length > 160) {
      await upload.cleanup();
      return NextResponse.json({ error: "Message is too long" }, { status: 400 });
    }

    if (!upload.files.length) {
      await upload.cleanup();
      return NextResponse.json({ error: "Choose a file to upload" }, { status: 400 });
    }

    const result = await uploadRepositoryFilesBatch({
      repositoryId: repository.id,
      authorId: session.user.id,
      files: upload.files.map((file, index) => ({
        ...file,
        path: file.path || file.originalName,
      })),
      message: message || undefined,
    });

    await upload.cleanup();

    if (!result.uploaded.length) {
      return NextResponse.json({ error: result.rejected[0]?.reason || "Upload failed", uploaded: result.uploaded, rejected: result.rejected }, { status: 400 });
    }

    return NextResponse.json({ path: result.uploaded[0]?.path, uploaded: result.uploaded, rejected: result.rejected }, { status: 201 });
  } catch (error) {
    await cleanupUpload?.();
    logServerError("upload", error);
    return NextResponse.json({ error: toSafeError(error, "Upload failed") }, { status: 400 });
  } finally {
    releaseSlot();
  }
}

export async function DELETE(request: Request, { params }: FilesRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const url = new URL(request.url);
  const path = url.searchParams.get("path");

  if (!path) {
    return NextResponse.json({ error: "Path is required" }, { status: 400 });
  }

  const file = await getPrisma().repositoryFile.findUnique({
    where: {
      repositoryId_path: {
        repositoryId: repository.id,
        path: normalizeRepoPath(path),
      },
    },
    select: { kind: true },
  });

  if (!file || file.kind !== FileKind.FILE) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  const { deleteRepositoryFile } = await import("@/server/repositories/files");
  await deleteRepositoryFile({
    repositoryId: repository.id,
    authorId: session.user.id,
    path,
  });

  return NextResponse.json({ ok: true });
}

type MultipartUpload = {
  fields: Record<string, string>;
  files: Array<{
    tmpPath: string;
    originalName: string;
    path: string;
    byteSize: number;
  }>;
  cleanup: () => Promise<void>;
};

async function parseMultipartUpload(request: Request, userId: string): Promise<MultipartUpload> {
  const contentType = request.headers.get("content-type");

  if (!contentType?.includes("multipart/form-data")) {
    throw new Error("Expected multipart upload");
  }

  if (!request.body) {
    throw new Error("Missing request body");
  }

  const env = getEnv();
  const fields: Record<string, string> = {};
  const pathFields: string[] = [];
  const tempFiles: string[] = [];
  const files: MultipartUpload["files"] = [];
  const savePromises: Promise<void>[] = [];
  const busboy = Busboy({
    headers: {
      "content-type": contentType,
    },
    limits: {
      files: 1000,
      fileSize: env.MAX_UPLOAD_SIZE_MB * 1024 * 1024,
      fields: 1100,
    },
  });

  busboy.on("field", (name, value) => {
    fields[name] = value;

    if (name === "paths" || name === "path") {
      pathFields.push(value);
    }
  });

  busboy.on("file", (_name, stream, info) => {
    const index = files.length + savePromises.length;
    const savePromise = writeUploadToTemp(stream, userId, env.MAX_UPLOAD_SIZE_MB * 1024 * 1024).then((saved) => {
      tempFiles.push(saved.tmpPath);
      files[index] = {
        tmpPath: saved.tmpPath,
        originalName: info.filename || "upload.bin",
        path: pathFields[index] || info.filename || "upload.bin",
        byteSize: saved.byteSize,
      };
    });
    savePromises.push(savePromise);
  });

  await new Promise<void>((resolve, reject) => {
    busboy.on("error", reject);
    busboy.on("finish", resolve);
    Readable.fromWeb(request.body as any).pipe(busboy);
  });
  await Promise.all(savePromises);
  const normalizedFiles = files.filter(Boolean).map((file, index) => ({
    ...file,
    path: pathFields[index] || file.path || file.originalName,
  }));

  return {
    fields,
    files: normalizedFiles,
    cleanup: async () => {
      const { rm } = await import("node:fs/promises");
      await Promise.all(tempFiles.map((tmpPath) => rm(tmpPath, { force: true })));
    },
  };
}
