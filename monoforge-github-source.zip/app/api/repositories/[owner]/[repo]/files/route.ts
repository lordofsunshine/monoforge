import { NextResponse } from "next/server";
import { Readable } from "node:stream";
import Busboy from "busboy";
import { auth } from "@/auth";
import { FileKind } from "@/generated/prisma/client";
import { getEnv } from "@/lib/env";
import { getPrisma } from "@/lib/prisma";
import { normalizeRepoPath } from "@/lib/repository/paths";
import { toSafeError, logServerError } from "@/lib/security/secure-error";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { uploadFileSchema } from "@/lib/validation/repository";
import { ensureRepoReadable, upsertRepositoryFileFromTemp } from "@/server/repositories/files";
import { acquireUploadSlot } from "@/server/storage/limits";
import { writeUploadToTemp } from "@/server/storage/service";

type FilesRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: FilesRouteProps) {
  const { owner, repo } = await params;
  const session = await auth();
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const url = new URL(request.url);
  const parentPath = url.searchParams.get("parentPath") ? normalizeRepoPath(url.searchParams.get("parentPath") || "") : "";
  const prisma = getPrisma();
  const files = await prisma.repositoryFile.findMany({
    where: {
      repositoryId: repository.id,
      parentPath,
    },
    orderBy: [{ kind: "asc" }, { name: "asc" }],
    take: 200,
  });

  return NextResponse.json({ files });
}

export async function POST(request: Request, { params }: FilesRouteProps) {
  const releaseSlot = await acquireUploadSlot().catch((error) => error as Error);

  if (releaseSlot instanceof Error) {
    return NextResponse.json({ error: releaseSlot.message }, { status: 429 });
  }

  const session = await auth();

  if (!session?.user?.id) {
    releaseSlot();
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    enforceRateLimit("upload", session.user.id);
  } catch (error) {
    releaseSlot();
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || repository.ownerId !== session.user.id) {
    releaseSlot();
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  let cleanupUpload: (() => Promise<void>) | null = null;

  try {
    const upload = await parseMultipartUpload(request, session.user.id);
    cleanupUpload = upload.cleanup;
  const parsed = uploadFileSchema.safeParse({
      path: upload.fields.path,
      message: upload.fields.message,
  });

  if (!parsed.success) {
      await upload.cleanup();
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

    if (!upload.file) {
    return NextResponse.json({ error: "Choose a file to upload" }, { status: 400 });
  }

    const path = await upsertRepositoryFileFromTemp({
    repositoryId: repository.id,
    authorId: session.user.id,
    path: parsed.data.path,
      tmpPath: upload.file.tmpPath,
      originalName: upload.file.originalName || parsed.data.path,
      byteSize: upload.file.byteSize,
    message: parsed.data.message || undefined,
  });

  return NextResponse.json({ path }, { status: 201 });
  } catch (error) {
    await cleanupUpload?.();
    logServerError("upload", error);
    return NextResponse.json({ error: toSafeError(error, "Upload failed") }, { status: 400 });
  } finally {
    releaseSlot();
  }
}

export async function DELETE(request: Request, { params }: FilesRouteProps) {
  const session = await auth();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo } = await params;
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const url = new URL(request.url);
  const path = url.searchParams.get("path");

  if (!path) {
    return NextResponse.json({ error: "Path is required" }, { status: 400 });
  }

  const file = await getPrisma().repositoryFile.findUnique({
    where: {
      repositoryId_path: {
        repositoryId: repository.id,
        path: normalizeRepoPath(path),
      },
    },
    select: { kind: true },
  });

  if (!file || file.kind !== FileKind.FILE) {
    return NextResponse.json({ error: "File not found" }, { status: 404 });
  }

  const { deleteRepositoryFile } = await import("@/server/repositories/files");
  await deleteRepositoryFile({
    repositoryId: repository.id,
    authorId: session.user.id,
    path,
  });

  return NextResponse.json({ ok: true });
}

type MultipartUpload = {
  fields: Record<string, string>;
  file: {
    tmpPath: string;
    originalName: string;
    byteSize: number;
  } | null;
  cleanup: () => Promise<void>;
};

async function parseMultipartUpload(request: Request, userId: string): Promise<MultipartUpload> {
  const contentType = request.headers.get("content-type");

  if (!contentType?.includes("multipart/form-data")) {
    throw new Error("Expected multipart upload");
  }

  if (!request.body) {
    throw new Error("Missing request body");
  }

  const env = getEnv();
  const fields: Record<string, string> = {};
  const tempFiles: string[] = [];
  let file: MultipartUpload["file"] = null;
  const savePromises: Promise<void>[] = [];
  const busboy = Busboy({
    headers: {
      "content-type": contentType,
    },
    limits: {
      files: 1,
      fileSize: env.MAX_UPLOAD_SIZE_MB * 1024 * 1024,
      fields: 8,
    },
  });

  busboy.on("field", (name, value) => {
    fields[name] = value;
  });

  busboy.on("file", (_name, stream, info) => {
    const savePromise = writeUploadToTemp(stream, userId, env.MAX_UPLOAD_SIZE_MB * 1024 * 1024).then((saved) => {
      tempFiles.push(saved.tmpPath);
      file = {
        tmpPath: saved.tmpPath,
        originalName: info.filename || "upload.bin",
        byteSize: saved.byteSize,
      };
    });
    savePromises.push(savePromise);
  });

  await new Promise<void>((resolve, reject) => {
    busboy.on("error", reject);
    busboy.on("finish", resolve);
    Readable.fromWeb(request.body as any).pipe(busboy);
  });
  await Promise.all(savePromises);

  return {
    fields,
    file,
    cleanup: async () => {
      const { rm } = await import("node:fs/promises");
      await Promise.all(tempFiles.map((tmpPath) => rm(tmpPath, { force: true })));
    },
  };
}
