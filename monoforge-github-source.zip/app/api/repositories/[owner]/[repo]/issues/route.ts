import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { IssueStatus, type Prisma } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { createIssueSchema, issueFiltersSchema } from "@/lib/validation/issues";
import { getRepositoryIssueContext } from "@/server/issues/access";
import { createIssue } from "@/server/issues/service";

type IssuesRouteProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export async function GET(request: Request, { params }: IssuesRouteProps) {
  const { owner, repo } = await params;
  const session = await auth();
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const url = new URL(request.url);
  const parsed = issueFiltersSchema.parse({
    status: url.searchParams.get("status") || "open",
    author: url.searchParams.get("author") || "",
    label: url.searchParams.get("label") || "",
    q: url.searchParams.get("q") || "",
    sort: url.searchParams.get("sort") || "newest",
  });
  const where: Prisma.IssueWhereInput = { repositoryId: repository.id };

  if (parsed.status !== "all") {
    where.status = parsed.status === "closed" ? IssueStatus.CLOSED : IssueStatus.OPEN;
  }

  if (parsed.author) where.author = { username: parsed.author };
  if (parsed.label) where.labels = { some: { label: { slug: parsed.label } } };
  if (parsed.q && parsed.q.length >= 2) {
    where.OR = [{ title: { contains: parsed.q, mode: "insensitive" } }, { digest: { contains: parsed.q, mode: "insensitive" } }];
  }

  const issues = await getPrisma().issue.findMany({
    where,
    orderBy: { createdAt: parsed.sort === "oldest" ? "asc" : "desc" },
    take: 50,
    include: {
      author: { select: { username: true } },
      labels: { include: { label: true } },
    },
  });

  return NextResponse.json({ issues });
}

export async function POST(request: Request, { params }: IssuesRouteProps) {
  const session = await auth();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    enforceRateLimit("issue", session.user.id);
  } catch (error) {
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const { owner, repo } = await params;
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const parsed = createIssueSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

  const issue = await createIssue(repository.id, session.user.id, parsed.data);
  return NextResponse.json({ issue }, { status: 201 });
}
