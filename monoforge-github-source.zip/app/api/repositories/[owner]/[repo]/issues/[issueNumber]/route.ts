import { NextResponse } from "next/server";
import { IssueStatus } from "@/generated/prisma/client";
import { getApiSession } from "@/lib/auth/api";
import { getPrisma } from "@/lib/prisma";
import { issueStateSchema, updateIssueSchema } from "@/lib/validation/issues";
import { canChangeIssueState, canDeleteIssue, getIssueForViewer, getRepositoryIssueContext } from "@/server/issues/access";
import { setIssueStatus, updateIssue } from "@/server/issues/service";

type IssueRouteProps = {
  params: Promise<{ owner: string; repo: string; issueNumber: string }>;
};

export async function GET(request: Request, { params }: IssueRouteProps) {
  const { owner, repo, issueNumber } = await params;
  const number = Number(issueNumber);
  const session = await getApiSession(request);
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository || !Number.isInteger(number)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const issue = await getIssueForViewer(repository.id, number).catch(() => null);

  if (!issue) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (session?.user?.id !== repository.ownerId) {
    issue.maintainerNote = null;
  }

  return NextResponse.json({ issue });
}

export async function PATCH(request: Request, { params }: IssueRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo, issueNumber } = await params;
  const number = Number(issueNumber);
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || !Number.isInteger(number)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const issue = await getIssueForViewer(repository.id, number).catch(() => null);

  if (!issue || !canChangeIssueState({ viewerId: session.user.id, ownerId: repository.ownerId, authorId: issue.authorId })) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await request.json().catch(() => null);
  const stateParsed = issueStateSchema.safeParse(body);

  if (stateParsed.success && Object.keys(body || {}).length === 1) {
    await setIssueStatus({
      issueId: issue.id,
      repositoryId: repository.id,
      actorId: session.user.id,
      number: issue.number,
      status: stateParsed.data.status as IssueStatus,
    });
    return NextResponse.json({ ok: true });
  }

  const parsed = updateIssueSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

  const updated = await updateIssue(issue.id, repository.id, parsed.data);
  return NextResponse.json({ issue: updated });
}

export async function DELETE(request: Request, { params }: IssueRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo, issueNumber } = await params;
  const number = Number(issueNumber);
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || !Number.isInteger(number)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const issue = await getIssueForViewer(repository.id, number).catch(() => null);

  if (!issue || !canDeleteIssue({ viewerId: session.user.id, ownerId: repository.ownerId })) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const prisma = getPrisma();
  await prisma.$transaction([
    prisma.issue.delete({ where: { id: issue.id } }),
    prisma.repository.update({ where: { id: repository.id }, data: { issueCount: { decrement: 1 } } }),
  ]);

  return NextResponse.json({ ok: true });
}
