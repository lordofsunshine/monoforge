import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { getPrisma } from "@/lib/prisma";
import { maintainerNoteSchema } from "@/lib/validation/issues";
import { getIssueForViewer, getRepositoryIssueContext } from "@/server/issues/access";

type NoteRouteProps = {
  params: Promise<{ owner: string; repo: string; issueNumber: string }>;
};

export async function PATCH(request: Request, { params }: NoteRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { owner, repo, issueNumber } = await params;
  const number = Number(issueNumber);
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || !Number.isInteger(number)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (repository.ownerId !== session.user.id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const issue = await getIssueForViewer(repository.id, number).catch(() => null);

  if (!issue) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const parsed = maintainerNoteSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

  if (!parsed.data.body) {
    await getPrisma().issueMaintainerNote.deleteMany({ where: { issueId: issue.id } });
    return NextResponse.json({ ok: true });
  }

  const note = await getPrisma().issueMaintainerNote.upsert({
    where: { issueId: issue.id },
    update: { body: parsed.data.body, authorId: session.user.id },
    create: { issueId: issue.id, authorId: session.user.id, body: parsed.data.body },
  });

  return NextResponse.json({ note });
}
