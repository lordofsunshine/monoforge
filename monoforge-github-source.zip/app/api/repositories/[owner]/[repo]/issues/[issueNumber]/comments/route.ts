import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { issueCommentSchema } from "@/lib/validation/issues";
import { getIssueForViewer, getRepositoryIssueContext } from "@/server/issues/access";
import { createIssueComment } from "@/server/issues/service";

type CommentsRouteProps = {
  params: Promise<{ owner: string; repo: string; issueNumber: string }>;
};

export async function POST(request: Request, { params }: CommentsRouteProps) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    enforceRateLimit("comment", session.user.id);
  } catch (error) {
    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }
    throw error;
  }

  const { owner, repo, issueNumber } = await params;
  const number = Number(issueNumber);
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository || !Number.isInteger(number)) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const issue = await getIssueForViewer(repository.id, number).catch(() => null);

  if (!issue) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const body = await request.json().catch(() => null);
  const parsed = issueCommentSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

  await createIssueComment(issue.id, repository.id, issue.number, session.user.id, parsed.data.body);
  return NextResponse.json({ ok: true }, { status: 201 });
}
