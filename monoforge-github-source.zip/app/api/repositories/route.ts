import { NextResponse } from "next/server";
import { auth } from "@/auth";
import { ActivityType, RepositoryVisibility } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { createRepositorySchema, slugifyRepositoryName } from "@/lib/validation/repository";

export async function POST(request: Request) {
  const session = await auth();

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const parsed = createRepositorySchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
  }

  const prisma = getPrisma();
  const slug = slugifyRepositoryName(parsed.data.name);
  const existing = await prisma.repository.findFirst({
    where: {
      ownerId: session.user.id,
      OR: [{ name: parsed.data.name }, { slug }],
    },
    select: { id: true },
  });

  if (existing) {
    return NextResponse.json({ error: "Repository name is already taken" }, { status: 409 });
  }

  const repository = await prisma.$transaction(async (tx) => {
    const created = await tx.repository.create({
      data: {
        ownerId: session.user.id,
        name: parsed.data.name,
        slug,
        description: parsed.data.description || null,
        visibility: parsed.data.visibility as RepositoryVisibility,
        commits: {
          create: {
            authorId: session.user.id,
            message: "Create repository",
            changedFiles: [],
          },
        },
      },
    });

    await tx.repoActivity.create({
      data: {
        repositoryId: created.id,
        actorId: session.user.id,
        type: ActivityType.REPOSITORY_CREATED,
        title: "Repository created",
      },
    });

    return created;
  });

  return NextResponse.json({ repository }, { status: 201 });
}
