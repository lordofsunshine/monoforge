import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { createRepositorySchema } from "@/lib/validation/repository";
import { createRepositoryForUser } from "@/server/repositories/service";

export async function POST(request: Request) {
  try {
    const session = await getApiSession(request);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json().catch(() => null);
    const parsed = createRepositorySchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message || "Invalid input" }, { status: 400 });
    }

    const repository = await createRepositoryForUser({ id: session.user.id, username: session.user.username }, parsed.data);

    return NextResponse.json({ repository }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Repository creation failed" }, { status: 400 });
  }
}
