import { NextResponse } from "next/server";
import { getPrisma } from "@/lib/prisma";
import { usernameSchema } from "@/lib/validation/auth";
import { RepositoryVisibility } from "@/generated/prisma/client";

type UserRouteProps = {
  params: Promise<{ username: string }>;
};

export async function GET(_request: Request, { params }: UserRouteProps) {
  const { username } = await params;
  const parsed = usernameSchema.safeParse(username);

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid username" }, { status: 400 });
  }

  const prisma = getPrisma();
  const user = await prisma.user.findUnique({
    where: { username: parsed.data },
    select: {
      id: true,
      username: true,
      name: true,
      bio: true,
      image: true,
      repositories: {
        where: { visibility: RepositoryVisibility.PUBLIC },
        orderBy: { updatedAt: "desc" },
        take: 20,
        select: {
          id: true,
          name: true,
          slug: true,
          description: true,
          starCount: true,
          issueCount: true,
          updatedAt: true,
        },
      },
    },
  });

  if (!user) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  return NextResponse.json({ user });
}
