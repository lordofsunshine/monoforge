import { NextResponse } from "next/server";
import { getApiSession } from "@/lib/auth/api";
import { getStorageStats } from "@/server/storage/stats";

export async function GET(request: Request) {
  const session = await getApiSession(request);

  if (!session?.user?.id) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const stats = await getStorageStats(session.user.id);

  return NextResponse.json({
    blobs: stats.blobs,
    variants: stats.variants,
    originalBytes: stats.originalBytes.toString(),
    storedBlobBytes: stats.storedBlobBytes.toString(),
    variantBytes: stats.variantBytes.toString(),
    userUsageBytes: stats.userUsageBytes?.toString() || "0",
  });
}
