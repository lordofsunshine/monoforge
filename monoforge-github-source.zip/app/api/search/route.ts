import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { auth } from "@/auth";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { parseSearchParams } from "@/lib/validation/search";
import { getCachedSearch, setCachedSearch } from "@/server/search/cache";
import { searchMonoForge } from "@/server/search/service";
import type { SearchResponse } from "@/types/search";

export async function GET(request: Request) {
  try {
    const session = await auth();
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";
    enforceRateLimit("search", session?.user?.id || ip);
    const { searchParams } = new URL(request.url);
    const input = parseSearchParams(searchParams);
    const viewerId = session?.user?.id;
    const cacheKey = JSON.stringify({ input, viewerId: viewerId ?? "anon" });
    const cached = getCachedSearch<SearchResponse>(cacheKey);

    if (cached) {
      return NextResponse.json(cached, {
        headers: { "Cache-Control": "private, max-age=15" },
      });
    }

    const response = await searchMonoForge(input, viewerId);
    setCachedSearch(cacheKey, response);

    return NextResponse.json(response, {
      headers: { "Cache-Control": "private, max-age=15" },
    });
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json({ error: "Invalid search query" }, { status: 400 });
    }

    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }

    return NextResponse.json({ error: "Search failed" }, { status: 500 });
  }
}
