import { NextResponse } from "next/server";
import { z, ZodError } from "zod";
import { getApiSession } from "@/lib/auth/api";
import { getEnv } from "@/lib/env";
import { enforceRateLimit, RateLimitError } from "@/lib/security/rate-limit";
import { translateMarkdown } from "@/server/markdown/translation";

const translateSchema = z.object({
  markdown: z.string().min(1),
  sourceLocale: z.enum(["en", "ru"]).optional(),
  targetLocale: z.enum(["en", "ru"]),
});

export async function POST(request: Request) {
  try {
    const env = getEnv();
    const session = await getApiSession(request);
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";
    enforceRateLimit("translate", session?.user?.id || ip);
    const input = translateSchema.parse(await request.json());

    if (input.markdown.length > env.TRANSLATE_MAX_CHARS) {
      return NextResponse.json({ error: "README is too long to translate safely." }, { status: 413 });
    }

    const markdown = await translateMarkdown(input);
    return NextResponse.json({ markdown });
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json({ error: "Invalid translation request." }, { status: 400 });
    }

    if (error instanceof RateLimitError) {
      return NextResponse.json({ error: error.message }, { status: 429 });
    }

    if (error instanceof Error && error.name === "AbortError") {
      return NextResponse.json({ error: "Translation timed out." }, { status: 504 });
    }

    return NextResponse.json({ error: "Translation failed." }, { status: 502 });
  }
}
