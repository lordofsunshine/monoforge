import Link from "next/link";
import { HomeCtaScene } from "@/components/home/home-cta-scene";
import { HomeFooter } from "@/components/home/home-footer";
import { HomeSearchDemo } from "@/components/home/home-search-demo";
import { LocalizedCount } from "@/components/system/localized-format";
import { LocalizedText } from "@/components/system/localized-text";
import { RepositoryStatus, RepositoryVisibility } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { getRepositoryLanguages } from "@/server/repositories/languages";

const features = [
  {
    title: "home.featureOneTitle",
    text: "home.featureOneText",
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M12 16V4M12 4l-4 4M12 4l4 4" />
        <path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
      </svg>
    ),
  },
  {
    title: "home.featureTwoTitle",
    text: "home.featureTwoText",
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
        <path d="M14 3v5h5M8.5 13h7M8.5 16.5h5" />
      </svg>
    ),
  },
  {
    title: "home.featureThreeTitle",
    text: "home.featureThreeText",
    icon: (
      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M21 11.5a8 8 0 0 1-11.6 7.1L4 20l1.4-5.4A8 8 0 1 1 21 11.5z" />
      </svg>
    ),
  },
] as const;

const steps = [
  ["home.stepOneTitle", "home.stepOneText"],
  ["home.stepTwoTitle", "home.stepTwoText"],
  ["home.stepThreeTitle", "home.stepThreeText"],
  ["home.stepFourTitle", "home.stepFourText"],
] as const;

const langShades = ["bg-foreground", "bg-secondary", "bg-faint", "bg-lineStrong", "bg-line", "bg-muted"];

async function getRecentRepositories() {
  const prisma = getPrisma();
  const repositories = await prisma.repository.findMany({
    where: {
      visibility: RepositoryVisibility.PUBLIC,
      status: RepositoryStatus.ACTIVE,
    },
    orderBy: { updatedAt: "desc" },
    take: 3,
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      fileCount: true,
      starCount: true,
      owner: { select: { username: true } },
    },
  });

  return Promise.all(
    repositories.map(async (repository) => ({
      repository,
      languages: await getRepositoryLanguages(repository.id),
    })),
  );
}

export default async function HomePage() {
  const recent = await getRecentRepositories();

  return (
    <>
      <section className="pb-10 pt-2">
        <div className="grid items-start gap-12 lg:grid-cols-2 lg:gap-14">
          <div>
            <p className="flex items-center gap-3 font-mono text-xs uppercase tracking-[0.16em] text-secondary">
              <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-subtle">
                <span className="h-2.5 w-2.5 rounded-full bg-foreground" />
              </span>
              <LocalizedText path="home.eyebrow" />
            </p>
            <h1 className="mt-7 max-w-[46rem] text-[clamp(2.75rem,4.3vw,4rem)] font-semibold leading-[0.98] tracking-normal text-foreground">
              <LocalizedText path="home.title" />
            </h1>
            <p className="mt-7 max-w-[43rem] text-[1.12rem] leading-[1.45] text-secondary">
              <LocalizedText path="home.description" />
            </p>
            <p className="mt-5 max-w-[45rem] text-secondary">
              <LocalizedText path="home.openSource" />{" "}
              <Link className="text-foreground" href="/lordofsunshine/monoforge">
                <LocalizedText path="home.githubLink" />
              </Link>
            </p>
            <div className="mt-7 flex flex-wrap gap-4">
              <Link className="mf-primary inline-flex h-[52px] min-w-40 items-center justify-center rounded-md border px-7 font-medium shadow-lg shadow-black/10" href="/register">
                <LocalizedText path="home.createAccount" />
              </Link>
              <Link className="inline-flex h-[52px] min-w-40 items-center justify-center rounded-md border border-line bg-surface/90 px-7 font-medium shadow-sm hover:border-lineStrong hover:bg-subtle" href="/explore">
                <LocalizedText path="home.exploreProjects" />
              </Link>
            </div>
            <div className="mt-9 flex flex-wrap gap-x-10 gap-y-6">
              <div className="grid gap-0.5">
                <span className="text-[1.6rem] font-semibold tracking-[-0.01em]">
                  <LocalizedText path="home.trustMonochromeValue" />
                </span>
                <span className="font-mono text-xs uppercase tracking-[0.14em] text-faint">
                  <LocalizedText path="home.trustMonochrome" />
                </span>
              </div>
              <div className="grid gap-0.5">
                <span className="text-[1.6rem] font-semibold tracking-[-0.01em]">
                  <LocalizedText path="home.trustLocalizedValue" />
                </span>
                <span className="font-mono text-xs uppercase tracking-[0.14em] text-faint">
                  <LocalizedText path="home.trustLocalized" />
                </span>
              </div>
              <div className="grid gap-0.5">
                <span className="text-[1.6rem] font-semibold tracking-[-0.01em]">
                  <LocalizedText path="home.trustOpenSourceValue" />
                </span>
                <span className="font-mono text-xs uppercase tracking-[0.14em] text-faint">
                  <LocalizedText path="home.trustOpenSource" />
                </span>
              </div>
            </div>
          </div>
          <HomeSearchDemo />
        </div>
      </section>

      <section className="py-[4.5rem]">
        <div className="max-w-[40rem]">
          <span className="font-mono text-xs uppercase tracking-[0.16em] text-secondary">
            <LocalizedText path="home.whyEyebrow" />
          </span>
          <h2 className="mt-3.5 text-[clamp(1.8rem,2.6vw,2.4rem)] font-semibold leading-[1.06] tracking-normal">
            <LocalizedText path="home.whyTitle" />
          </h2>
          <p className="mt-4 text-[1.05rem] leading-[1.55] text-secondary">
            <LocalizedText path="home.whyText" />
          </p>
        </div>
        <div className="mt-10 grid overflow-hidden rounded-2xl border border-line bg-surface md:grid-cols-3">
          {features.map((feature) => (
            <article className="grid gap-5 border-b border-line px-7 py-9 last:border-b-0 md:border-b-0 md:border-r md:last:border-r-0" key={feature.title}>
              <div className="flex h-[3.25rem] w-[3.25rem] items-center justify-center rounded-[0.6rem] border border-line bg-background text-secondary">
                {feature.icon}
              </div>
              <div>
                <h3 className="text-[1.2rem] font-semibold leading-[1.1]">
                  <LocalizedText path={feature.title} />
                </h3>
                <p className="mt-2.5 text-secondary leading-[1.6]">
                  <LocalizedText path={feature.text} />
                </p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="pb-[4.5rem] pt-0">
        <div className="max-w-[40rem]">
          <span className="font-mono text-xs uppercase tracking-[0.16em] text-secondary">
            <LocalizedText path="home.stepsEyebrow" />
          </span>
          <h2 className="mt-3.5 text-[clamp(1.8rem,2.6vw,2.4rem)] font-semibold leading-[1.06] tracking-normal">
            <LocalizedText path="home.stepsTitle" />
          </h2>
        </div>
        <div className="mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {steps.map(([title, text], index) => (
            <article className="rounded-[0.85rem] border border-line bg-surface p-6 transition duration-200 hover:-translate-y-0.5 hover:border-lineStrong" key={title}>
              <span className="font-mono text-[0.78rem] text-faint">{String(index + 1).padStart(2, "0")}</span>
              <h3 className="mt-3 text-[1.05rem] font-semibold leading-[1.1]">
                <LocalizedText path={title} />
              </h3>
              <p className="mt-2 text-[0.92rem] leading-[1.55] text-secondary">
                <LocalizedText path={text} />
              </p>
            </article>
          ))}
        </div>
      </section>

      <section className="pb-[4.5rem] pt-0">
        <div className="max-w-[40rem]">
          <span className="font-mono text-xs uppercase tracking-[0.16em] text-secondary">
            <LocalizedText path="home.recentEyebrow" />
          </span>
          <h2 className="mt-3.5 text-[clamp(1.8rem,2.6vw,2.4rem)] font-semibold leading-[1.06] tracking-normal">
            <LocalizedText path="home.recentTitle" />
          </h2>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {recent.map(({ repository, languages }) => (
            <Link
              className="grid gap-3.5 rounded-[0.85rem] border border-line bg-surface p-5 transition duration-200 hover:-translate-y-0.5 hover:border-lineStrong"
              href={`/${repository.owner.username}/${repository.slug}`}
              key={repository.id}
            >
              <span className="font-mono text-[0.85rem] text-secondary">
                <b className="font-semibold text-foreground">{repository.slug}</b> by {repository.owner.username}
              </span>
              <span className="min-h-[2.8rem] text-[0.92rem] leading-[1.5] text-secondary">
                {repository.description || <LocalizedText path="common.noDescription" />}
              </span>
              {languages.length ? (
                <div className="flex h-1.5 overflow-hidden rounded-full border border-line bg-subtle">
                  {languages.map((item, index) => (
                    <span className={langShades[index % langShades.length]} key={item.language} style={{ width: `${item.percent}%` }} />
                  ))}
                </div>
              ) : null}
              <div className="flex flex-wrap gap-4 font-mono text-xs text-faint">
                {languages[0] ? (
                  <span>
                    {languages[0].language} {languages[0].percent}%
                  </span>
                ) : null}
                <span>★ {repository.starCount}</span>
                <span>
                  <LocalizedCount value={repository.fileCount} unit="files" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="pb-4 pt-0">
        <div className="relative overflow-hidden rounded-[1.25rem] border border-line bg-surface px-8 py-12 text-center">
          <HomeCtaScene />
          <h2 className="relative z-[2] mx-auto max-w-[34rem] text-[clamp(1.9rem,3vw,2.6rem)] font-semibold leading-[1.06] tracking-normal">
            <LocalizedText path="home.ctaTitle" />
          </h2>
          <p className="relative z-[2] mx-auto mt-4 max-w-[34rem] text-secondary">
            <LocalizedText path="home.ctaText" />
          </p>
          <div className="relative z-[2] mt-7 flex flex-wrap justify-center gap-4">
            <Link className="mf-primary inline-flex h-[52px] min-w-40 items-center justify-center rounded-md border px-7 font-medium shadow-lg shadow-black/10" href="/register">
              <LocalizedText path="home.createAccount" />
            </Link>
            <Link className="inline-flex h-[52px] min-w-40 items-center justify-center rounded-md border border-line bg-surface/90 px-7 font-medium shadow-sm hover:border-lineStrong hover:bg-subtle" href="/explore">
              <LocalizedText path="home.exploreProjects" />
            </Link>
          </div>
        </div>
      </section>

      <HomeFooter />
    </>
  );
}
