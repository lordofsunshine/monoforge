import Link from "next/link";
import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { FileTree } from "@/components/repository/file-tree";
import { getPrisma } from "@/lib/prisma";
import { normalizeRepoPath } from "@/lib/repository/paths";
import { ensureRepoReadable } from "@/server/repositories/files";

type TreePageProps = {
  params: Promise<{ owner: string; repo: string; path?: string[] }>;
};

export default async function TreePage({ params }: TreePageProps) {
  const { owner, repo, path } = await params;
  const session = await auth();
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    notFound();
  }

  const currentPath = path?.length ? normalizeRepoPath(path.join("/")) : "";
  const prisma = getPrisma();
  const files = await prisma.repositoryFile.findMany({
    where: {
      repositoryId: repository.id,
      parentPath: currentPath,
    },
    orderBy: [{ kind: "asc" }, { name: "asc" }],
  });

  return (
    <section className="grid gap-6">
      <header className="border-b border-line pb-5">
        <p className="font-mono text-sm text-secondary">
          <Link className="underline-offset-4 hover:underline" href={`/${repository.owner.username}/${repository.slug}`}>
            {repository.owner.username} / {repository.slug}
          </Link>
        </p>
        <h1 className="mt-2 text-2xl font-semibold">{currentPath || "/"}</h1>
      </header>
      <FileTree owner={repository.owner.username} repo={repository.slug} files={files} />
    </section>
  );
}
