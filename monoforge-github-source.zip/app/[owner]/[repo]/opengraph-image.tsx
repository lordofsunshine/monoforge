import { ImageResponse } from "next/og";
import { notFound } from "next/navigation";
import { RepositoryStatus, RepositoryVisibility } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { getRepositoryLanguages } from "@/server/repositories/languages";

export const alt = "MonoForge repository";
export const size = {
  width: 1200,
  height: 630,
};
export const contentType = "image/png";
export const runtime = "nodejs";

type ImageProps = {
  params: Promise<{ owner: string; repo: string }>;
};

function clamp(value: string | null | undefined, max: number) {
  if (!value) {
    return "";
  }

  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
}

export default async function Image({ params }: ImageProps) {
  const { owner, repo } = await params;
  const repository = await getPrisma().repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      visibility: RepositoryVisibility.PUBLIC,
      status: RepositoryStatus.ACTIVE,
      owner: { username: owner.toLowerCase() },
    },
    select: {
      id: true,
      name: true,
      slug: true,
      description: true,
      fileCount: true,
      issueCount: true,
      starCount: true,
      readmePath: true,
      owner: { select: { username: true } },
    },
  });

  if (!repository) {
    notFound();
  }

  const languages = await getRepositoryLanguages(repository.id);
  const title = clamp(repository.name, 52);
  const description = clamp(repository.description || "A public project on MonoForge.", 120);

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          background: "#0b0b0b",
          color: "#f6f6f6",
          fontFamily: "Arial",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.055) 1px, transparent 1px)",
            backgroundSize: "34px 34px",
          }}
        />
        <div
          style={{
            position: "absolute",
            right: 68,
            top: 78,
            width: 270,
            height: 270,
            border: "1px solid rgba(255,255,255,0.18)",
            borderRadius: 44,
            background:
              "repeating-linear-gradient(90deg, rgba(255,255,255,0.9) 0 14px, transparent 14px 26px), repeating-linear-gradient(0deg, rgba(255,255,255,0.18) 0 11px, transparent 11px 29px)",
            opacity: 0.22,
          }}
        />
        <div
          style={{
            position: "relative",
            display: "flex",
            flexDirection: "column",
            gap: 28,
            margin: 68,
            padding: 48,
            width: 850,
            height: 494,
            border: "1px solid rgba(255,255,255,0.2)",
            borderRadius: 30,
            background: "rgba(12,12,12,0.9)",
            boxShadow: "0 34px 90px rgba(0,0,0,0.48)",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", color: "#a3a3a3", fontSize: 19, letterSpacing: 3 }}>
            <span>MONOFORGE</span>
            <span>PUBLIC REPOSITORY</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ color: "#bdbdbd", fontSize: 24 }}>{`${repository.owner.username} / ${repository.slug}`}</div>
            <div style={{ fontSize: 54, fontWeight: 780, lineHeight: 1.02 }}>{title}</div>
            <div style={{ color: "#d4d4d4", fontSize: 25, lineHeight: 1.35, maxWidth: 720 }}>{description}</div>
          </div>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap", color: "#e5e5e5", fontSize: 18 }}>
            <span style={{ border: "1px solid rgba(255,255,255,0.18)", borderRadius: 9, padding: "10px 14px" }}>{repository.fileCount} files</span>
            <span style={{ border: "1px solid rgba(255,255,255,0.18)", borderRadius: 9, padding: "10px 14px" }}>{repository.starCount} stars</span>
            <span style={{ border: "1px solid rgba(255,255,255,0.18)", borderRadius: 9, padding: "10px 14px" }}>{repository.issueCount} issues</span>
            <span style={{ border: "1px solid rgba(255,255,255,0.18)", borderRadius: 9, padding: "10px 14px" }}>{repository.readmePath ? "README" : "no README"}</span>
          </div>
          {languages.length ? (
            <div style={{ display: "flex", gap: 12, color: "#a3a3a3", fontSize: 18 }}>
              {languages.slice(0, 4).map((item) => (
                <span key={item.language}>
                  {item.language} {item.percent}%
                </span>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    ),
    size,
  );
}
