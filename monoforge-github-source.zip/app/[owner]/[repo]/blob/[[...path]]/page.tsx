import Link from "next/link";
import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { BinaryFilePreview } from "@/components/repository/binary-file-preview";
import { CodeViewer } from "@/components/repository/code-viewer";
import { FileActionsMenu } from "@/components/repository/file-actions-menu";
import { ImagePreview } from "@/components/repository/image-preview";
import { LargeFileWarning } from "@/components/repository/large-file-warning";
import { ReadmePreview } from "@/components/repository/readme-preview";
import { LocalizedText } from "@/components/system/localized-text";
import { FileKind } from "@/generated/prisma/client";
import { formatBytes } from "@/lib/format";
import { getPrisma } from "@/lib/prisma";
import { normalizeRepoPath } from "@/lib/repository/paths";
import { ensureRepoReadable, isMarkdownPath, readRepositoryFileText } from "@/server/repositories/files";

type BlobPageProps = {
  params: Promise<{ owner: string; repo: string; path?: string[] }>;
};

function encodeRepoPath(repoPath: string) {
  return repoPath.split("/").map(encodeURIComponent).join("/");
}

export default async function BlobPage({ params }: BlobPageProps) {
  const { owner, repo, path } = await params;
  const session = await auth();
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository || !path?.length) {
    notFound();
  }

  const repoPath = normalizeRepoPath(path.join("/"));
  const file = await getPrisma().repositoryFile.findUnique({
    where: {
      repositoryId_path: {
        repositoryId: repository.id,
        path: repoPath,
      },
    },
    include: {
      blob: {
        include: { variants: true },
      },
    },
  });

  if (!file || file.kind !== FileKind.FILE) {
    notFound();
  }

  const content = await readRepositoryFileText(file.id);
  const canWrite = session?.user?.id === repository.ownerId;
  const encodedFilePath = encodeRepoPath(file.path);
  const rawHref = `/api/repositories/${repository.owner.username}/${repository.slug}/raw/${encodedFilePath}`;
  const downloadHref = `/api/repositories/${repository.owner.username}/${repository.slug}/download/${encodedFilePath}`;
  const previewVariant = file.blob?.variants.find((variant) => variant.kind === "IMAGE_PREVIEW");
  const normalizedMime = file.mimeType?.split(";")[0]?.trim().toLowerCase() || "";
  const isImage = normalizedMime.startsWith("image/") && normalizedMime !== "image/svg+xml";
  const imageSrc = previewVariant ? `/api/repositories/${repository.owner.username}/${repository.slug}/thumbnail/${encodedFilePath}?kind=preview` : rawHref;

  return (
    <section className="grid gap-6">
      <header className="flex flex-wrap items-start justify-between gap-4 border-b border-line pb-5">
        <div className="min-w-0">
          <p className="font-mono text-sm text-secondary">
            <Link className="underline-offset-4 hover:underline" href={`/${repository.owner.username}/${repository.slug}`}>
              {repository.owner.username} / {repository.slug}
            </Link>
          </p>
          <h1 className="mt-2 truncate font-mono text-xl font-semibold">{file.path}</h1>
          <p className="mt-2 font-mono text-xs text-faint">
            {formatBytes(file.size)} · {file.mimeType || "unknown"}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Link className="inline-flex h-9 items-center rounded-md border border-line bg-surface px-3 text-sm hover:border-lineStrong hover:bg-subtle" href={rawHref}>
            <LocalizedText path="repo.raw" />
          </Link>
          <FileActionsMenu
            owner={repository.owner.username}
            repo={repository.slug}
            path={file.path}
            downloadHref={downloadHref}
            repositoryId={repository.id}
            canWrite={canWrite}
            signedIn={Boolean(session?.user)}
          />
        </div>
      </header>
      {isImage ? (
        <ImagePreview
          path={file.path}
          rawHref={rawHref}
          downloadHref={downloadHref}
          previewHref={imageSrc}
          width={previewVariant?.width}
          height={previewVariant?.height}
        />
      ) : content !== null ? (
        isMarkdownPath(file.path) ? (
          <ReadmePreview content={content} owner={repository.owner.username} repo={repository.slug} sourcePath={file.path} />
        ) : (
          <CodeViewer code={content} language={file.language} path={file.path} rawHref={rawHref} downloadHref={downloadHref} />
        )
      ) : Number(file.size) > 1024 * 1024 ? (
        <LargeFileWarning path={file.path} rawHref={rawHref} downloadHref={downloadHref} />
      ) : (
        <BinaryFilePreview path={file.path} rawHref={rawHref} downloadHref={downloadHref} mimeType={file.mimeType} />
      )}
    </section>
  );
}
