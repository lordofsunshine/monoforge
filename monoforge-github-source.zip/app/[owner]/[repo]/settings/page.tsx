import { notFound, redirect } from "next/navigation";
import { auth } from "@/auth";
import { RepoSettingsForm } from "@/components/repository/repo-settings-form";
import { WebhookManager } from "@/components/repository/webhook-manager";
import { LocalizedText } from "@/components/system/localized-text";
import { getPrisma } from "@/lib/prisma";

type RepoSettingsPageProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export default async function RepoSettingsPage({ params }: RepoSettingsPageProps) {
  const { owner, repo } = await params;
  const session = await auth();

  if (!session?.user?.id) {
    redirect("/login");
  }

  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      owner: { username: owner.toLowerCase() },
    },
    include: {
      owner: {
        select: { username: true },
      },
      webhooks: {
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          url: true,
          events: true,
          status: true,
          lastStatus: true,
          lastError: true,
          lastSentAt: true,
          createdAt: true,
        },
      },
    },
  });

  if (!repository) {
    notFound();
  }

  if (repository.ownerId !== session.user.id) {
    redirect(`/${repository.owner.username}/${repository.slug}`);
  }

  return (
    <section className="grid w-full max-w-3xl gap-6">
      <div className="border-b border-line pb-5">
        <p className="font-mono text-sm text-secondary">
          {repository.owner.username} / {repository.slug}
        </p>
        <h1 className="mt-2 text-2xl font-semibold">
          <LocalizedText path="repoForm.repositorySettings" />
        </h1>
      </div>
      <RepoSettingsForm repositoryId={repository.id} name={repository.name} description={repository.description || ""} visibility={repository.visibility} />
      <WebhookManager
        owner={repository.owner.username}
        repo={repository.slug}
        initialWebhooks={repository.webhooks.map((webhook) => ({
          ...webhook,
          lastSentAt: webhook.lastSentAt?.toISOString() ?? null,
          createdAt: webhook.createdAt.toISOString(),
        }))}
      />
    </section>
  );
}
