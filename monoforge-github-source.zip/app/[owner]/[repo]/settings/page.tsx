import { notFound, redirect } from "next/navigation";
import { auth } from "@/auth";
import { RepoSettingsForm } from "@/components/repository/repo-settings-form";
import { LocalizedText } from "@/components/system/localized-text";
import { getPrisma } from "@/lib/prisma";

type RepoSettingsPageProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export default async function RepoSettingsPage({ params }: RepoSettingsPageProps) {
  const { owner, repo } = await params;
  const session = await auth();

  if (!session?.user?.id) {
    redirect("/login");
  }

  const prisma = getPrisma();
  const repository = await prisma.repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      owner: { username: owner.toLowerCase() },
    },
    include: {
      owner: {
        select: { username: true },
      },
    },
  });

  if (!repository) {
    notFound();
  }

  if (repository.ownerId !== session.user.id) {
    redirect(`/${repository.owner.username}/${repository.slug}`);
  }

  return (
    <section className="mx-auto grid max-w-2xl gap-6">
      <div className="border-b border-line pb-5">
        <p className="font-mono text-sm text-secondary">
          {repository.owner.username} / {repository.slug}
        </p>
        <h1 className="mt-2 text-2xl font-semibold">
          <LocalizedText path="repoForm.repositorySettings" />
        </h1>
      </div>
      <RepoSettingsForm repositoryId={repository.id} name={repository.name} description={repository.description || ""} visibility={repository.visibility} />
    </section>
  );
}
