import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { auth } from "@/auth";
import { IssueForm } from "@/components/issues/issue-form";
import { LocalizedText } from "@/components/system/localized-text";
import { createIssueAction } from "@/lib/issues/actions";
import { getRepositoryIssueContext } from "@/server/issues/access";
import { getRepositoryLabels } from "@/server/issues/labels";

type NewIssuePageProps = {
  params: Promise<{ owner: string; repo: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function NewIssuePage({ params, searchParams }: NewIssuePageProps) {
  const { owner, repo } = await params;
  const search = await searchParams;
  const session = await auth();

  if (!session?.user?.id) {
    redirect("/login");
  }

  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session.user.id).catch(() => null);

  if (!repository) {
    notFound();
  }

  const labels = await getRepositoryLabels(repository.id);
  const action = createIssueAction.bind(null, repository.owner.username, repository.slug);
  const sourcePath = stringValue(search.path) || "";
  const sourceLineRaw = stringValue(search.line);
  const sourceLine = sourceLineRaw ? Number(sourceLineRaw) : null;

  return (
    <section className="grid w-full max-w-3xl gap-6">
      <header className="border-b border-line pb-5">
        <p className="font-mono text-sm text-secondary">
          <Link className="underline-offset-4 hover:underline" href={`/${repository.owner.username}/${repository.slug}/issues`}>
            {repository.owner.username} / {repository.slug} / issues
          </Link>
        </p>
        <h1 className="mt-2 text-2xl font-semibold">
          <LocalizedText path="issuesPage.newIssue" />
        </h1>
      </header>
      <div className="rounded-lg border border-line bg-surface p-5">
        <IssueForm
          action={action}
          labels={labels}
          submitLabel="issuesPage.createIssue"
          defaults={{
            sourcePath,
            sourceLine,
          }}
        />
      </div>
    </section>
  );
}

function stringValue(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}
