import Link from "next/link";
import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { IssueFilters } from "@/components/issues/issue-filters";
import { IssueList } from "@/components/issues/issue-list";
import { LocalizedText } from "@/components/system/localized-text";
import { IssueStatus, type Prisma } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { issueFiltersSchema } from "@/lib/validation/issues";
import { getRepositoryIssueContext } from "@/server/issues/access";
import { getRepositoryLabels } from "@/server/issues/labels";

type IssuesPageProps = {
  params: Promise<{ owner: string; repo: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function IssuesPage({ params, searchParams }: IssuesPageProps) {
  const { owner, repo } = await params;
  const rawSearch = await searchParams;
  const session = await auth();
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    notFound();
  }

  const parsed = issueFiltersSchema.parse({
    status: stringValue(rawSearch.status) || "open",
    author: stringValue(rawSearch.author) || "",
    label: stringValue(rawSearch.label) || "",
    q: stringValue(rawSearch.q) || "",
    sort: stringValue(rawSearch.sort) || "newest",
  });

  const where: Prisma.IssueWhereInput = {
    repositoryId: repository.id,
  };

  if (parsed.status !== "all") {
    where.status = parsed.status === "closed" ? IssueStatus.CLOSED : IssueStatus.OPEN;
  }

  if (parsed.author) {
    where.author = { username: parsed.author };
  }

  if (parsed.label) {
    where.labels = { some: { label: { slug: parsed.label } } };
  }

  if (parsed.q && parsed.q.length >= 2) {
    where.OR = [{ title: { contains: parsed.q, mode: "insensitive" } }, { digest: { contains: parsed.q, mode: "insensitive" } }];
  }

  const [labels, issues] = await Promise.all([
    getRepositoryLabels(repository.id),
    getPrisma().issue.findMany({
      where,
      orderBy: { createdAt: parsed.sort === "oldest" ? "asc" : "desc" },
      take: 50,
      include: {
        author: { select: { username: true } },
        labels: { include: { label: true } },
      },
    }),
  ]);

  return (
    <section className="grid gap-6">
      <header className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-5">
        <div>
          <p className="font-mono text-sm text-secondary">
            <Link className="underline-offset-4 hover:underline" href={`/${repository.owner.username}/${repository.slug}`}>
              {repository.owner.username} / {repository.slug}
            </Link>
          </p>
          <h1 className="mt-2 text-2xl font-semibold">
            <LocalizedText path="issuesPage.title" />
          </h1>
        </div>
        <div className="flex gap-2">
          <Link className="h-9 rounded-md border border-line px-3 py-2 text-sm hover:border-lineStrong hover:bg-subtle" href={`/${repository.owner.username}/${repository.slug}/board`}>
            <LocalizedText path="issuesPage.board" />
          </Link>
          {session?.user ? (
            <Link className="mf-primary h-9 rounded-md border px-3 py-2 text-sm" href={`/${repository.owner.username}/${repository.slug}/issues/new`}>
              <LocalizedText path="issuesPage.newIssue" />
            </Link>
          ) : null}
        </div>
      </header>
      <IssueFilters owner={repository.owner.username} repo={repository.slug} labels={labels} active={parsed} />
      <IssueList owner={repository.owner.username} repo={repository.slug} issues={issues} />
    </section>
  );
}

function stringValue(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}
