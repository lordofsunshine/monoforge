import Link from "next/link";
import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { CommentForm } from "@/components/issues/comment-form";
import { DeleteIssueButton } from "@/components/issues/delete-issue-button";
import { IssueActions } from "@/components/issues/issue-actions";
import { IssueComment } from "@/components/issues/issue-comment";
import { IssueForm } from "@/components/issues/issue-form";
import { LabelBadge } from "@/components/issues/label-badge";
import { MaintainerNoteForm } from "@/components/issues/maintainer-note-form";
import { Markdown } from "@/components/issues/markdown";
import { LocalizedText } from "@/components/system/localized-text";
import { formatDate } from "@/lib/format";
import { addCommentAction, saveMaintainerNoteAction, updateIssueAction } from "@/lib/issues/actions";
import { canChangeIssueState, canDeleteIssue, getIssueForViewer, getRepositoryIssueContext } from "@/server/issues/access";
import { getRepositoryLabels } from "@/server/issues/labels";

type IssuePageProps = {
  params: Promise<{ owner: string; repo: string; issueNumber: string }>;
};

export default async function IssuePage({ params }: IssuePageProps) {
  const { owner, repo, issueNumber } = await params;
  const number = Number(issueNumber);

  if (!Number.isInteger(number)) {
    notFound();
  }

  const session = await auth();
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    notFound();
  }

  const [issue, labels] = await Promise.all([getIssueForViewer(repository.id, number).catch(() => null), getRepositoryLabels(repository.id)]);

  if (!issue) {
    notFound();
  }

  const canChange = canChangeIssueState({ viewerId: session?.user?.id, ownerId: repository.ownerId, authorId: issue.authorId });
  const canDelete = canDeleteIssue({ viewerId: session?.user?.id, ownerId: repository.ownerId });
  const ownerRepo = { owner: repository.owner.username, repo: repository.slug };
  const updateAction = updateIssueAction.bind(null, ownerRepo.owner, ownerRepo.repo, issue.number);
  const commentAction = addCommentAction.bind(null, ownerRepo.owner, ownerRepo.repo, issue.number);
  const noteAction = saveMaintainerNoteAction.bind(null, ownerRepo.owner, ownerRepo.repo, issue.number);

  return (
    <section className="grid gap-6">
      <header className="flex flex-wrap items-start justify-between gap-4 border-b border-line pb-5">
        <div className="min-w-0">
          <p className="font-mono text-sm text-secondary">
            <Link className="underline-offset-4 hover:underline" href={`/${repository.owner.username}/${repository.slug}/issues`}>
              {repository.owner.username} / {repository.slug} / issues
            </Link>
          </p>
          <h1 className="mt-2 text-2xl font-semibold">
            #{issue.number} {issue.title}
          </h1>
          <p className="mt-2 text-sm text-secondary">{issue.digest}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {issue.labels.map(({ label }) => (
              <LabelBadge key={label.id} label={label} />
            ))}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <IssueActions owner={ownerRepo.owner} repo={ownerRepo.repo} number={issue.number} status={issue.status} canChange={canChange} />
          {canDelete ? <DeleteIssueButton owner={ownerRepo.owner} repo={ownerRepo.repo} number={issue.number} /> : null}
        </div>
      </header>
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <main className="grid gap-6">
          <article className="rounded-lg border border-line bg-surface">
            <div className="border-b border-line bg-subtle px-4 py-3 font-mono text-xs text-faint">
              @{issue.author.username} opened on {formatDate(issue.createdAt)} · {issue.status.toLowerCase()} · {issue.priority.toLowerCase()}
            </div>
            <div className="p-4">
              <Markdown content={issue.body} />
              {issue.sourcePath ? (
                <p className="mt-4 rounded-md border border-line bg-subtle px-3 py-2 font-mono text-xs text-secondary">
                  <LocalizedText path="issuesPage.from" /> {issue.sourcePath}
                  {issue.sourceLine ? `:${issue.sourceLine}` : ""}
                </p>
              ) : null}
            </div>
          </article>
          <section className="rounded-lg border border-line bg-surface p-4">
            <h2 className="font-mono text-xs uppercase tracking-[0.14em] text-secondary">
              <LocalizedText path="issuesPage.threadMinimal" />
            </h2>
            <div className="mt-2">
              {issue.comments.length ? issue.comments.map((comment) => <IssueComment key={comment.id} comment={comment} />) : <p className="py-6 text-sm text-secondary"><LocalizedText path="activity.empty" /></p>}
            </div>
          </section>
          {session?.user ? (
            <section className="rounded-lg border border-line bg-surface p-4">
              <h2 className="mb-3 font-mono text-xs uppercase tracking-[0.14em] text-secondary">
                <LocalizedText path="issuesPage.addComment" />
              </h2>
              <CommentForm action={commentAction} />
            </section>
          ) : null}
        </main>
        <aside className="grid content-start gap-4">
          {canChange ? (
            <details className="rounded-lg border border-line bg-surface p-4">
              <summary className="cursor-pointer font-mono text-xs uppercase tracking-[0.14em] text-secondary">
                <LocalizedText path="issuesPage.editIssue" />
              </summary>
              <div className="mt-4">
                <IssueForm
                  action={updateAction}
                  labels={labels}
                  submitLabel="common.save"
                  defaults={{
                    title: issue.title,
                    body: issue.body,
                    priority: issue.priority,
                    boardStatus: issue.boardStatus,
                    labelSlugs: issue.labels.map(({ label }) => label.slug),
                  }}
                />
              </div>
            </details>
          ) : null}
          {canDelete ? <MaintainerNoteForm action={noteAction} defaultValue={issue.maintainerNote?.body || ""} /> : null}
        </aside>
      </div>
    </section>
  );
}
