import type { Metadata } from "next";
import { headers } from "next/headers";
import Link from "next/link";
import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { FileTree } from "@/components/repository/file-tree";
import { LanguageStrip } from "@/components/repository/language-strip";
import { ReadmePreview } from "@/components/repository/readme-preview";
import { RepoActionsMenu } from "@/components/repository/repo-actions-menu";
import { RepoFingerprintTile } from "@/components/repository/repo-fingerprint-tile";
import { StarButton } from "@/components/repository/star-button";
import { UploadFileForm } from "@/components/repository/upload-file-form";
import { LocalizedCount, LocalizedDate } from "@/components/system/localized-format";
import { LocalizedText } from "@/components/system/localized-text";
import { FileKind, RepositoryStatus, RepositoryVisibility } from "@/generated/prisma/client";
import { formatBytes } from "@/lib/format";
import { getPrisma } from "@/lib/prisma";
import { ensureRepoReadable, readRepositoryFileText } from "@/server/repositories/files";
import { getRepositoryLanguages } from "@/server/repositories/languages";
import { recordRepositoryView } from "@/server/repositories/views";

type RepositoryPageProps = {
  params: Promise<{ owner: string; repo: string }>;
};

type CommitPreview = {
  id: string;
  message: string;
  changedFiles: string[];
  filesAdded: number;
  filesChanged: number;
  filesDeleted: number;
  bytesAdded: bigint;
  bytesDeleted: bigint;
  createdAt: Date;
  author: {
    username: string;
  };
};

export async function generateMetadata({ params }: RepositoryPageProps): Promise<Metadata> {
  const { owner, repo } = await params;
  const session = await auth();
  const repository = await getPrisma().repository.findFirst({
    where: {
      slug: repo.toLowerCase(),
      status: RepositoryStatus.ACTIVE,
      owner: {
        username: owner.toLowerCase(),
      },
    },
    select: {
      name: true,
      slug: true,
      description: true,
      visibility: true,
      updatedAt: true,
      fileCount: true,
      starCount: true,
      ownerId: true,
      owner: {
        select: {
          username: true,
        },
      },
    },
  });

  if (!repository || (repository.visibility !== RepositoryVisibility.PUBLIC && repository.ownerId !== session?.user?.id)) {
    return {
      title: "Repository not found",
      robots: { index: false, follow: false },
    };
  }

  const isPublic = repository.visibility === RepositoryVisibility.PUBLIC;
  const title = `${repository.name} by ${repository.owner.username}`;
  const description =
    repository.description ||
    `${repository.owner.username}/${repository.slug} on MonoForge: ${repository.fileCount} files and ${repository.starCount} stars in a quiet public project workspace.`;
  const repositoryUrl = `https://monoforge.org/${repository.owner.username}/${repository.slug}`;
  const repositoryImageUrl = `${repositoryUrl}/opengraph-image?v=${repository.updatedAt.getTime()}`;

  return {
    title,
    description,
    alternates: {
      canonical: repositoryUrl,
    },
    openGraph: {
      type: "article",
      url: repositoryUrl,
      title,
      description,
      siteName: "MonoForge",
      modifiedTime: repository.updatedAt.toISOString(),
      images: [
        {
          url: repositoryImageUrl,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [repositoryImageUrl],
    },
    robots: {
      index: isPublic,
      follow: isPublic,
    },
  };
}

function groupRecentCommits(commits: CommitPreview[]) {
  const groups: Array<CommitPreview & { ids: string[]; lastCommitTime: number }> = [];

  for (const commit of commits) {
    const previous = groups.at(-1);
    const nearPrevious = previous ? Math.abs(previous.lastCommitTime - commit.createdAt.getTime()) < 120_000 : false;

    if (previous && previous.message === commit.message && previous.author.username === commit.author.username && nearPrevious) {
      previous.ids.push(commit.id);
      previous.changedFiles.push(...commit.changedFiles);
      previous.filesAdded += commit.filesAdded;
      previous.filesChanged += commit.filesChanged;
      previous.filesDeleted += commit.filesDeleted;
      previous.bytesAdded = BigInt(previous.bytesAdded) + BigInt(commit.bytesAdded);
      previous.bytesDeleted = BigInt(previous.bytesDeleted) + BigInt(commit.bytesDeleted);
      previous.lastCommitTime = commit.createdAt.getTime();
      continue;
    }

    groups.push({ ...commit, changedFiles: [...commit.changedFiles], ids: [commit.id], lastCommitTime: commit.createdAt.getTime() });
  }

  return groups.slice(0, 8);
}

export default async function RepositoryPage({ params }: RepositoryPageProps) {
  const { owner, repo } = await params;
  const [session, headerStore] = await Promise.all([auth(), headers()]);
  const nonce = headerStore.get("x-nonce");
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch((error) => {
    console.error("[RepositoryPage] Error reading repository:", error);
    return null;
  });

  if (!repository) {
    notFound();
  }

  await recordRepositoryView(repository.id, session?.user?.id).catch((error) => {
    console.error("[RepositoryPage] Error recording view:", error);
    return undefined;
  });

  const prisma = getPrisma();
  const [files, readme, commits, star, openIssues, languages] = await Promise.all([
    prisma.repositoryFile.findMany({
      where: {
        repositoryId: repository.id,
        parentPath: "",
      },
      orderBy: [{ kind: "asc" }, { name: "asc" }],
      take: 1000,
    }),
    repository.readmePath
      ? prisma.repositoryFile
          .findUnique({
            where: {
              repositoryId_path: {
                repositoryId: repository.id,
                path: repository.readmePath,
              },
            },
            select: { id: true },
          })
          .then((file) => (file ? readRepositoryFileText(file.id) : null))
      : Promise.resolve(null),
    prisma.commitLite.findMany({
      where: { repositoryId: repository.id },
      orderBy: { createdAt: "desc" },
      take: 30,
      include: {
        author: {
          select: { username: true },
        },
      },
    }),
    session?.user?.id
      ? prisma.star.findUnique({
          where: {
            userId_repositoryId: {
              userId: session.user.id,
              repositoryId: repository.id,
            },
          },
          select: { id: true },
        })
      : Promise.resolve(null),
    prisma.issue.count({
      where: { repositoryId: repository.id, status: "OPEN" },
    }),
    getRepositoryLanguages(repository.id),
  ]);

  let previewContent = readme;
  let previewPath = repository.readmePath;

  if (!previewContent && !previewPath) {
    const fallback = files.find((f) => f.kind === FileKind.FILE && /^(license|contributing)(\.md|\.txt)?$/i.test(f.name));
    if (fallback) {
      previewPath = fallback.path;
      previewContent = await readRepositoryFileText(fallback.id);
    }
  }

  const canWrite = session?.user?.id === repository.ownerId;
  const archiveUrl = `/api/repositories/${repository.owner.username}/${repository.slug}/archive`;
  const recentCommits = groupRecentCommits(commits);
  const repoUrl = `https://monoforge.org/${repository.owner.username}/${repository.slug}`;
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "SoftwareSourceCode",
    name: repository.name,
    description: repository.description || `${repository.owner.username}/${repository.slug} on MonoForge`,
    codeRepository: repoUrl,
    url: repoUrl,
    dateModified: repository.updatedAt.toISOString(),
    programmingLanguage: languages.map((item) => item.language),
    author: {
      "@type": "Person",
      name: repository.owner.username,
      url: `https://monoforge.org/u/${repository.owner.username}`,
    },
  };

  return (
    <section className="grid min-w-0 gap-6">
      {repository.visibility === RepositoryVisibility.PUBLIC ? <script nonce={nonce ?? undefined} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData).replace(/</g, '\\u003c') }} /> : null}
      <header className="border-b border-line pb-6">
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-start">
          <div className="grid min-w-0 gap-3 sm:grid-cols-[56px_minmax(0,1fr)]">
            <RepoFingerprintTile value={`${repository.owner.username}/${repository.slug}`} />
            <div className="min-w-0">
              <p className="break-words font-mono text-sm text-secondary">
                <Link className="hover:text-foreground" href={`/u/${repository.owner.username}`}>
                  {repository.owner.username}
                </Link>{" "}
                / {repository.slug}
              </p>
              <div className="mt-2 flex min-w-0 flex-wrap items-center gap-2">
                <h1 className="min-w-0 max-w-full break-words text-2xl font-semibold leading-tight md:text-3xl">{repository.name}</h1>
                <span className="rounded-sm border border-line px-2 py-0.5 font-mono text-[11px] uppercase text-secondary">
                  <LocalizedText path={repository.visibility === "PRIVATE" ? "common.private" : "common.public"} />
                </span>
              </div>
              <p className="mt-3 max-w-2xl text-sm leading-6 text-secondary">{repository.description || <LocalizedText path="common.noDescription" />}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 lg:justify-end">
            {session?.user ? <StarButton owner={repository.owner.username} repo={repository.slug} starred={Boolean(star)} starCount={repository.starCount} /> : null}
            <Link className="inline-flex h-9 items-center rounded-md border border-line bg-surface px-3 text-sm hover:border-lineStrong hover:bg-subtle" href={`/${repository.owner.username}/${repository.slug}/issues`}>
              <LocalizedText path="repo.issues" />
            </Link>
            <RepoActionsMenu archiveUrl={archiveUrl} owner={repository.owner.username} repo={repository.slug} canWrite={canWrite} />
          </div>
        </div>
        <div className="mt-5 flex flex-wrap gap-3 font-mono text-xs text-faint">
          <span>
            <LocalizedCount value={repository.fileCount} unit="files" />
          </span>
          <span>{formatBytes(repository.repoSize)}</span>
          <span>
            <LocalizedCount value={openIssues} unit="openIssues" />
          </span>
          <span>
            <LocalizedCount value={repository.starCount} unit="stars" />
          </span>
          <span>
            <LocalizedText path="repo.updated" /> <LocalizedDate value={repository.updatedAt} />
          </span>
        </div>
      </header>
      <div className="grid min-w-0 gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(300px,360px)]">
        <div className="grid min-w-0 gap-6">
          <FileTree owner={repository.owner.username} repo={repository.slug} files={files.filter((file) => file.kind === FileKind.DIRECTORY || file.kind === FileKind.FILE)} />
          <ReadmePreview
            content={previewContent}
            createHref={canWrite ? `/${repository.owner.username}/${repository.slug}/blob/README.md` : undefined}
            owner={repository.owner.username}
            repo={repository.slug}
            sourcePath={previewPath}
          />
        </div>
        <aside className="grid min-w-0 content-start gap-4">
          {canWrite ? <UploadFileForm owner={repository.owner.username} repo={repository.slug} /> : null}
          <div className="min-w-0 rounded-lg border border-line bg-surface p-4">
            <h2 className="font-mono text-xs uppercase tracking-[0.14em] text-secondary">
              <LocalizedText path="repo.recentChanges" />
            </h2>
            <div className="mt-3 grid gap-3">
              {recentCommits.length ? (
                recentCommits.map((commit) => {
                  const uniqueFiles = Array.from(new Set(commit.changedFiles));
                  const shownFiles = uniqueFiles.slice(0, 4);

                  return (
                    <div className="min-w-0 border-b border-line pb-3 last:border-b-0 last:pb-0" key={commit.ids.join(":")}>
                      <p className="break-words text-sm font-medium">{commit.message}</p>
                      <p className="mt-1 font-mono text-xs text-faint">
                        {commit.author.username} · <LocalizedDate value={commit.createdAt} />
                      </p>
                      {uniqueFiles.length ? (
                        <div className="mt-2 min-w-0 rounded-md border border-line bg-subtle px-2 py-1.5">
                          <p className="font-mono text-xs text-secondary">
                            <LocalizedCount value={uniqueFiles.length} unit="fileChanged" />
                          </p>
                          <p className="mt-1 min-w-0 truncate font-mono text-xs text-faint">
                            {shownFiles.join(", ")}
                            {uniqueFiles.length > shownFiles.length ? (
                              <>
                                {" "}
                                +{uniqueFiles.length - shownFiles.length} <LocalizedText path="common.more" />
                              </>
                            ) : null}
                          </p>
                        </div>
                      ) : null}
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-secondary">
                  <LocalizedText path="repo.noHistory" />
                </p>
              )}
            </div>
          </div>
          <LanguageStrip languages={languages} compact />
        </aside>
      </div>
    </section>
  );
}
