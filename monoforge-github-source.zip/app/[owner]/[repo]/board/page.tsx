import Link from "next/link";
import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { ProjectBoard } from "@/components/issues/project-board";
import { LocalizedText } from "@/components/system/localized-text";
import { IssueStatus } from "@/generated/prisma/client";
import { getPrisma } from "@/lib/prisma";
import { getRepositoryIssueContext } from "@/server/issues/access";

type BoardPageProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export default async function BoardPage({ params }: BoardPageProps) {
  const { owner, repo } = await params;
  const session = await auth();
  const repository = await getRepositoryIssueContext(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    notFound();
  }

  const issues = await getPrisma().issue.findMany({
    where: {
      repositoryId: repository.id,
      status: IssueStatus.OPEN,
    },
    orderBy: { updatedAt: "desc" },
    take: 100,
    include: {
      author: { select: { username: true } },
      labels: { include: { label: true } },
    },
  });

  return (
    <section className="grid gap-6">
      <header className="flex flex-wrap items-end justify-between gap-4 border-b border-line pb-5">
        <div>
          <p className="font-mono text-sm text-secondary">
            <Link className="underline-offset-4 hover:underline" href={`/${repository.owner.username}/${repository.slug}`}>
              {repository.owner.username} / {repository.slug}
            </Link>
          </p>
          <h1 className="mt-2 text-2xl font-semibold">
            <LocalizedText path="issuesPage.projectBoard" />
          </h1>
        </div>
        <Link className="h-9 rounded-md border border-line px-3 py-2 text-sm hover:border-lineStrong hover:bg-subtle" href={`/${repository.owner.username}/${repository.slug}/issues`}>
          <LocalizedText path="issuesPage.title" />
        </Link>
      </header>
      <ProjectBoard owner={repository.owner.username} repo={repository.slug} issues={issues} />
    </section>
  );
}
