import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { ActivityPulse } from "@/components/repository/activity-pulse";
import { RepoHealthStrip } from "@/components/repository/repo-health-strip";
import { StorageSavingsCard } from "@/components/repository/storage-savings-card";
import { LocalizedText } from "@/components/system/localized-text";
import { ensureRepoReadable } from "@/server/repositories/files";
import { getActivityPulse, getRepoMetrics } from "@/server/repositories/metrics";

type StoragePageProps = {
  params: Promise<{ owner: string; repo: string }>;
};

export default async function RepositoryStoragePage({ params }: StoragePageProps) {
  const { owner, repo } = await params;
  const session = await auth();
  const repository = await ensureRepoReadable(owner.toLowerCase(), repo.toLowerCase(), session?.user?.id).catch(() => null);

  if (!repository) {
    notFound();
  }

  const [metrics, pulse] = await Promise.all([getRepoMetrics(repository.id), getActivityPulse(repository.id)]);

  return (
    <section className="grid gap-6">
      <header className="border-b border-line pb-5">
        <p className="font-mono text-xs uppercase tracking-[0.14em] text-secondary">
          <LocalizedText path="repo.storage" />
        </p>
        <h1 className="mt-2 text-2xl font-semibold">
          {repository.owner.username}/{repository.slug}
        </h1>
      </header>
      <RepoHealthStrip metrics={metrics} />
      <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
        <StorageSavingsCard metrics={metrics} />
        <ActivityPulse days={pulse} />
      </div>
    </section>
  );
}
